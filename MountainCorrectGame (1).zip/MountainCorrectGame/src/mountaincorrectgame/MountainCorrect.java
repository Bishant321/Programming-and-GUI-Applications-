/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package mountaincorrectgame;
 


/**
 *
 * @author bishantghartichhetri
 */
 import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class MountainCorrect extends javax.swing.JFrame {
    // Game constants
    private static final int TOTAL_PAIRS = 6;
    private static final int BASE_SCORE = 50;
    private static final int SCORE_PENALTY_PER_ATTEMPT = 2;
    private static final int CARD_WIDTH = 120;
    private static final int CARD_HEIGHT = 120;
    private static final int FLIP_DELAY_MS = 1000;
    private static final Color CARD_BACK_COLOR = new Color(70, 130, 180);
    private static final Color MATCHED_CARD_COLOR = new Color(34, 139, 34);
    
    // Game variables
    private JButton firstSelection = null;
    private JButton secondSelection = null;
    private int pairsFound = 0;
    private int attempts = 0;
    private int score = 0;
    private int secondsElapsed = 0;
    private boolean gameInProgress = false;
    
    // Timers
    private javax.swing.Timer flipBackTimer;
    private javax.swing.Timer gameTimer;
    
    // Image paths
    private final String[] IMAGE_PATHS = {
        "/mountaincorrectgame/mount 1.jpeg",
        "/mountaincorrectgame/mont2.jpeg",
        "/mountaincorrectgame/mount-3.jpeg",
        "/mountaincorrectgame/mount-4 (1).jpeg",
        "/mountaincorrectgame/mount-5 (1).jpeg",
        "/mountaincorrectgame/mount-6.jpeg"
    };
    
    // GUI components
    private JButton[] cardButtons;
    private JLabel scoreLabel;
    private JLabel timerLabel;
    private JLabel attemptsLabel;
    private JLabel statusLabel;
    private JLabel instructionsLabel;
    private Map<JButton, Integer> cardImageIndices = new HashMap<>();
    private Map<JButton, ImageIcon> cardImages = new HashMap<>();

    public MountainCorrect() {
        initComponents();
        setupGame();
        setSize(800, 800);
        setResizable(false);
        setLocationRelativeTo(null);
        setTitle("Mountain Matching Game");
    }
    
    private void setupGame() {
        // Initialize UI components
        scoreLabel = new JLabel("Score: 0");
        timerLabel = new JLabel("Time: 00:00");
        attemptsLabel = new JLabel("Attempts: 0");
        statusLabel = new JLabel("Game Started! Click any card to begin");
        instructionsLabel = new JLabel("<html><div style='text-align: center;'>"
            + "<b>Instructions:</b><br>"
            + "1. Click on any card to reveal the mountain image<br>"
            + "2. Find all matching pairs of mountain images<br>"
            + "3. Matching cards will stay revealed<br>"
            + "4. Non-matching cards will flip back automatically<br>"
            + "5. Try to complete the game with the fewest attempts!</div></html>");
        
        // Style the labels
        Font labelFont = new Font("Arial", Font.BOLD, 14);
        scoreLabel.setFont(labelFont);
        timerLabel.setFont(labelFont);
        attemptsLabel.setFont(labelFont);
        statusLabel.setFont(new Font("Arial", Font.BOLD, 16));
        statusLabel.setForeground(Color.BLUE);
        instructionsLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        
        cardButtons = new JButton[]{
            jButton1, jButton2, jButton3, jButton4,
            jButton5, jButton6, jButton7, jButton8,
            jButton9, jButton10, jButton11, jButton12
        };
        
        setupTimers();
        
        // Configure card buttons
        for (JButton button : cardButtons) {
            button.addActionListener(new CardButtonListener());
            button.setToolTipText("Click to reveal mountain image");
            resetCardAppearance(button);
        }
        
        jButton13.addActionListener(e -> resetGame());
        jButton14.addActionListener(e -> showInstructions());
        resetGame();
    }
    
    private void showInstructions() {
        JOptionPane.showMessageDialog(this, 
            "Mountain Matching Game Instructions:\n\n" +
            "1. The game board contains 12 cards (6 pairs of mountain images)\n" +
            "2. Click on a card to reveal the mountain image\n" +
            "3. Click on another card to try to find its match\n" +
            "4. If the two cards match, they will stay revealed\n" +
            "5. If they don't match, they will flip back automatically\n" +
            "6. Try to find all pairs with the fewest attempts\n" +
            "7. Your score is calculated based on time and attempts\n\n" +
            "Click the Restart Game button to start a new game at any time",
            "Game Instructions", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void setupTimers() {
        flipBackTimer = new javax.swing.Timer(FLIP_DELAY_MS, e -> {
            if (firstSelection != null && secondSelection != null) {
                flipCardBack(firstSelection);
                flipCardBack(secondSelection);
                firstSelection = null;
                secondSelection = null;
                statusLabel.setText("No match! Try again.");
            }
        });
        flipBackTimer.setRepeats(false);
        
        gameTimer = new javax.swing.Timer(1000, e -> {
            secondsElapsed++;
            updateTimerDisplay();
        });
    }
    
    private void resetGame() {
        gameInProgress = true;
        pairsFound = 0;
        attempts = 0;
        score = 0;
        secondsElapsed = 0;
        firstSelection = null;
        secondSelection = null;
        cardImageIndices.clear();
        cardImages.clear();
        
        flipBackTimer.stop();
        gameTimer.stop();
        
        updateScoreDisplay();
        updateAttemptsDisplay();
        updateTimerDisplay();
        statusLabel.setText("Game Started! Click any card to begin");
        
        initializeCardImages();
        gameTimer.start();
    }
    
    private void initializeCardImages() {
        ArrayList<Integer> imageIndices = new ArrayList<>();
        for (int i = 0; i < TOTAL_PAIRS; i++) {
            imageIndices.add(i);
            imageIndices.add(i);
        }
        Collections.shuffle(imageIndices);
        
        for (int i = 0; i < cardButtons.length; i++) {
            JButton button = cardButtons[i];
            button.setEnabled(true);
            resetCardAppearance(button);
            
            if (i < imageIndices.size()) {
                int imageIndex = imageIndices.get(i);
                cardImageIndices.put(button, imageIndex);
                loadCardImage(button, imageIndex);
            }
        }
    }
    
    private void loadCardImage(JButton button, int imageIndex) {
        try {
            ImageIcon icon = new ImageIcon(getClass().getResource(IMAGE_PATHS[imageIndex]));
            if (icon.getImageLoadStatus() != MediaTracker.COMPLETE) {
                throw new Exception("Image failed to load");
            }
            Image img = icon.getImage().getScaledInstance(CARD_WIDTH, CARD_HEIGHT, Image.SCALE_SMOOTH);
            cardImages.put(button, new ImageIcon(img));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading image: " + IMAGE_PATHS[imageIndex], 
                "Error", JOptionPane.ERROR_MESSAGE);
            button.setEnabled(false);
            button.setText("X");
        }
    }
    
    private void resetCardAppearance(JButton button) {
        button.setIcon(null);
        button.setText("?");
        button.setBackground(CARD_BACK_COLOR);
        button.setPreferredSize(new Dimension(CARD_WIDTH, CARD_HEIGHT));
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 24));
    }
    
    private void flipCard(JButton button) {
        button.setIcon(cardImages.get(button));
        button.setText("");
        button.setBackground(Color.WHITE);
    }
    
    private void flipCardBack(JButton button) {
        resetCardAppearance(button);
    }
    
    private void checkMatch() {
        if (firstSelection == null || secondSelection == null) return;
        
        attempts++;
        updateAttemptsDisplay();
        
        Integer firstIndex = cardImageIndices.get(firstSelection);
        Integer secondIndex = cardImageIndices.get(secondSelection);
        
        if (firstIndex != null && secondIndex != null && firstIndex.equals(secondIndex)) {
            handleMatch();
        } else {
            handleMismatch();
        }
    }
    
    private void handleMatch() {
        pairsFound++;
        score += Math.max(0, BASE_SCORE - (attempts / SCORE_PENALTY_PER_ATTEMPT));
        updateScoreDisplay();
        statusLabel.setText("Match found! " + (TOTAL_PAIRS - pairsFound) + " pairs remaining");
        
        firstSelection.setEnabled(false);
        secondSelection.setEnabled(false);
        firstSelection.setBackground(MATCHED_CARD_COLOR);
        secondSelection.setBackground(MATCHED_CARD_COLOR);
        
        firstSelection = null;
        secondSelection = null;
        
        if (pairsFound == TOTAL_PAIRS) {
            endGame();
        }
    }
    
    private void handleMismatch() {
        statusLabel.setText("No match! Cards will flip back...");
        flipBackTimer.start();
    }
    
    private void endGame() {
        gameInProgress = false;
        gameTimer.stop();
        JOptionPane.showMessageDialog(this, 
            String.format("Congratulations! You Won!\nScore: %d\nTime: %02d:%02d\nAttempts: %d", 
                score, secondsElapsed/60, secondsElapsed%60, attempts), 
            "Game Over", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void updateScoreDisplay() {
        scoreLabel.setText("Score: " + score);
    }
    
    private void updateAttemptsDisplay() {
        attemptsLabel.setText("Attempts: " + attempts);
    }
    
    private void updateTimerDisplay() {
        timerLabel.setText(String.format("Time: %02d:%02d", secondsElapsed/60, secondsElapsed%60));
    }
    
    private class CardButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (!gameInProgress) return;
            
            JButton clickedButton = (JButton) e.getSource();
            if (!clickedButton.isEnabled() || clickedButton == firstSelection) return;
            
            flipCard(clickedButton);
            
            if (firstSelection == null) {
                firstSelection = clickedButton;
                statusLabel.setText("Select another card to find a match");
            } else if (secondSelection == null) {
                secondSelection = clickedButton;
                checkMatch();
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountaincorrectgame/mount 1.jpeg"))); // NOI18N
        jButton1.setText("jButton1");
        jButton1.setPreferredSize(new java.awt.Dimension(80, 100));
        jButton1.setSize(new java.awt.Dimension(86, 100));

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountaincorrectgame/mount 1.jpeg"))); // NOI18N
        jButton2.setText("jButton2");

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountaincorrectgame/mont2.jpeg"))); // NOI18N
        jButton3.setText("jButton3");

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountaincorrectgame/mont2.jpeg"))); // NOI18N
        jButton4.setText("jButton4");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountaincorrectgame/mount-3.jpeg"))); // NOI18N
        jButton5.setText("jButton5");

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountaincorrectgame/mount-3.jpeg"))); // NOI18N
        jButton6.setText("jButton6");

        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountaincorrectgame/mount-4 (1).jpeg"))); // NOI18N
        jButton7.setText("jButton7");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountaincorrectgame/mount-4 (1).jpeg"))); // NOI18N
        jButton8.setText("jButton8");

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountaincorrectgame/mount-5 (1).jpeg"))); // NOI18N
        jButton9.setText("jButton9");

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountaincorrectgame/mount-5 (1).jpeg"))); // NOI18N
        jButton10.setText("jButton10");

        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountaincorrectgame/mount-6.jpeg"))); // NOI18N
        jButton11.setText("jButton11");

        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountaincorrectgame/mount-6.jpeg"))); // NOI18N
        jButton12.setText("jButton12");

        jLabel1.setFont(new java.awt.Font("American Typewriter", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 0, 255));
        jLabel1.setText("Welcome to Mountain Correct Game");
        jLabel1.setSize(new java.awt.Dimension(55, 60));

        jButton13.setBackground(new java.awt.Color(153, 153, 0));
        jButton13.setFont(new java.awt.Font("American Typewriter", 1, 18)); // NOI18N
        jButton13.setForeground(new java.awt.Color(255, 51, 51));
        jButton13.setText("Restart Game");

        jButton14.setBackground(new java.awt.Color(102, 102, 255));
        jButton14.setFont(new java.awt.Font("American Typewriter", 1, 18)); // NOI18N
        jButton14.setForeground(new java.awt.Color(153, 0, 153));
        jButton14.setText("Check Guess");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(jButton13)
                        .addGap(37, 37, 37)
                        .addComponent(jButton14)))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton8)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE, false)
                    .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
                    .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton13)
                    .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton14ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MountainCorrect.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MountainCorrect.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MountainCorrect.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MountainCorrect.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MountainCorrect().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
